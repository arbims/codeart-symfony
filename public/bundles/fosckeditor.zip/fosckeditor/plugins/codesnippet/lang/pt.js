/**
 * @license Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 * CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'pt', {
	button: 'Inserir fragmento de código',
	codeContents: 'Conteúdo do código',
	emptySnippetError: 'A code snippet cannot be empty.', // MISSING
	language: 'Idioma',
	title: 'Segmento de código',
	pathName: 'Fragmento de código'
} );
